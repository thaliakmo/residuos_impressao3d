<?php
require 'config.php';
session_start(); // Inicia a sessão

class LoginApp {
    private $email;
    private $senha;

    public function __construct($email, $senha) {
        $this->email = $email;
        $this->senha = $senha;
    }

    public function autenticar() {
        global $conn;

        $sql = "SELECT * FROM usuarios WHERE email = '$this->email' AND senha = '$this->senha' LIMIT 1";
        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {
            $usuario = $result->fetch_assoc();
            // Salva o ID do usuário na sessão
            $_SESSION['usuario_id'] = $usuario['id'];
            return json_encode([
                "status" => "ok",
                "id" => $usuario['id'],
                "nome" => $usuario['nome']
            ]);
        } else {
            return json_encode(["status" => "erro"]);
        }
    }
}

// Captura dos dados POST
$email = $_POST['email'];
$senha = $_POST['senha'];

// Criação e execução da autenticação
$loginApp = new LoginApp($email, $senha);
echo $loginApp->autenticar();
?>