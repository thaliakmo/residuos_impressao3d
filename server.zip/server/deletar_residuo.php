<?php
include "config.php";

$id = $_POST['id'] ?? '';

if (!$id) {
    echo "ID inválido.";
    exit;
}

$sql = "DELETE FROM residuos WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();

echo "Resíduo deletado.";
?>
