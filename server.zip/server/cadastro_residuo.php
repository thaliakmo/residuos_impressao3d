<?php

include "config.php"; // Inclui o arquivo de configuração

// Recupera dados enviados via POST
$uso = $_POST['uso'] ?? [];
$materiais = $_POST['materiais'] ?? [];
$gasto_mensal = $_POST['gasto_mensal'] ?? 0;
$residuo_mensal = $_POST['residuo_mensal'] ?? 0;
$usuario_id = $_POST['usuario_id'] ?? ''; // Recupera o usuario_id do POST
$disponibilizado = true; // Define como TRUE (será armazenado como 1)

// Garante que $uso e $materiais sejam arrays
if (!is_array($uso)) {
    $uso = [$uso];
}
if (!is_array($materiais)) {
    $materiais = [$materiais];
}

// Converte arrays para strings separadas por vírgula
$uso_string = implode(",", $uso);
$materiais_string = implode(",", $materiais);

// Prepara e executa a query de inserção
if ($usuario_id) {
    $sql = "INSERT INTO residuos (usuario_id, uso, materiais, gasto_mensal, residuo_mensal, disponibilizado)
            VALUES (?, ?, ?, ?, ?, ?)"; // Modificado: Adicionado 'disponibilizado'
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("issddi", $usuario_id, $uso_string, $materiais_string, $gasto_mensal, $residuo_mensal, $disponibilizado); // Modificado: bind_param
    $success = $stmt->execute();

    if ($success) {
        echo json_encode(["status" => "sucesso", "message" => "Resíduo cadastrado com sucesso!"]);
    } else {
        echo json_encode(["status" => "erro", "message" => "Erro ao cadastrar resíduo: " . $stmt->error]);
    }
} else {
    echo json_encode(["status" => "erro", "message" => "Erro: Usuário não autenticado."]);
}

$conn->close();

?>