<?php
include "config.php";

$id = $_POST['id'] ?? '';

if (!$id) {
    echo json_encode(['success' => false, 'message' => 'ID inválido.']);
    exit;
}

$sql = "UPDATE residuos SET disponibilizado = TRUE WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();

if ($stmt->affected_rows > 0) {
    echo json_encode(['success' => true, 'message' => 'Resíduo disponibilizado.']);
} else {
    echo json_encode(['success' => false, 'message' => 'Erro ao disponibilizar o resíduo.']);
}