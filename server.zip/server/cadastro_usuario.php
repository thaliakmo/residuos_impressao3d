<?php
include "config.php"; // Inclui o arquivo de configuração


// Recebe os dados do formulário
$nome = $_POST['nome'] ?? '';
$email = $_POST['email'] ?? '';
$cidade = $_POST['cidade'] ?? '';
$bairro = $_POST['bairro'] ?? '';
$senha = $_POST['senha'] ?? '';

// Verifica se o email já está cadastrado
$sql = "SELECT * FROM usuarios WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo "email_cadastrado";
} else {
    $sql = "INSERT INTO usuarios (nome, email, cidade, bairro, senha) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $nome, $email, $cidade, $bairro, $senha);
    if ($stmt->execute()) {
        echo "sucesso";
    } else {
        echo "erro_ao_cadastrar";
    }
}

$conn->close();
?>