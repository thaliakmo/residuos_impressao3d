<?php
include "config.php";

$id = $_POST['id'] ?? '';
$motivo = $_POST['motivo'] ?? '';
$onde = $_POST['onde'] ?? '';

if (!$id || !$motivo) {
    echo "Dados inválidos.";
    exit;
}

$sql = "UPDATE residuos SET disponibilizado = FALSE, motivo_cancelamento = ?, onde_cancelamento = ? WHERE id = ?"; // Modified SQL
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssi", $motivo, $onde, $id);

if ($stmt->execute()) {
    echo "Disponibilidade cancelada.";
} else {
    echo "Erro ao cancelar disponibilidade.";
}
?>