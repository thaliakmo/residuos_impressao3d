<?php
include "config.php";

// Verifica se o parâmetro id foi passado
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $id = $_GET['id'];

    // Usa prepared statement para evitar SQL Injection
    $stmt = $conn->prepare("SELECT * FROM residuos WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $resultado = $stmt->get_result();

    // Verifica se o resíduo foi encontrado
    if ($resultado->num_rows > 0) {
        $residuo = $resultado->fetch_assoc();

        // Transforma os campos de uso e materiais em arrays
        $uso = explode(",", $residuo['uso']);
        $materiais = explode(",", $residuo['materiais']);

        // Retorna os dados como JSON
        echo json_encode([
            "id" => $residuo['id'],
            "gasto_mensal" => $residuo['gasto_mensal'],
            "residuo_mensal" => $residuo['residuo_mensal'],
            "uso" => $uso,
            "materiais" => $materiais
        ]);
    } else {
        // Caso o resíduo não seja encontrado
        echo json_encode(["error" => "Resíduo não encontrado."]);
    }
} else {
    // Caso o parâmetro id não seja passado
    echo json_encode(["error" => "ID não fornecido."]);
}
?>
