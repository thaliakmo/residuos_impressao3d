<?php

// Permite CORS

header("Access-Control-Allow-Origin: *");

header("Access-Control-Allow-Methods: POST, GET, OPTIONS");

header("Access-Control-Allow-Headers: Content-Type");


header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");

header("X-Content-Type-Options: nosniff");



$servername = "localhost";
$username = "root";
$password = "";
$dbname = "residuos3d";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
   die(json_encode(["status" => "erro", "message" => "Falha na conexão com o banco de dados: " . $conn->connect_error]));
}

$conn->set_charset("utf8");
?>



