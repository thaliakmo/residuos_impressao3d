<?php
include "config.php";

$usuario_id = $_POST['usuario_id'] ?? '';

if (!$usuario_id) {
    echo json_encode([]);
    exit;
}

$sql = "SELECT * FROM residuos WHERE usuario_id = ? AND disponibilizado = TRUE"; // Consulta Filtrada
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();

$result = $stmt->get_result();
$dados = [];

while ($row = $result->fetch_assoc()) {
    $dados[] = $row;
}

echo json_encode($dados);
?>