<?php
require_once 'config.php';

$id = $_POST['id'] ?? null;
$usuario_id = $_POST['usuario_id'] ?? null;
$gasto = $_POST['gasto_mensal'] ?? 0;
$residuo = $_POST['residuo_mensal'] ?? 0;
$uso = $_POST['uso'] ?? [];
$materiais = $_POST['materiais'] ?? [];

if (!$id || !$usuario_id) {
    echo "Erro: ID ou Usuário não informado.";
    exit;
}

// Transforma arrays em strings para salvar no banco
$uso_str = is_array($uso) ? implode(",", $uso) : $uso;
$materiais_str = is_array($materiais) ? implode(",", $materiais) : $materiais;

try {
    $sql = "UPDATE residuos SET
                gasto_mensal = ?,
                residuo_mensal = ?,
                uso = ?,
                materiais = ?
            WHERE id = ? AND usuario_id = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ddssii", $gasto, $residuo, $uso_str, $materiais_str, $id, $usuario_id);

    if ($stmt->execute()) {
        echo "Atualização com sucesso!";
    } else {
        echo "Erro ao atualizar.";
    }
} catch (mysqli_sql_exception $e) {
    echo "Erro: " . $e->getMessage();
}
?>